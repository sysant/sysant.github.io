# Changelog

This file documents all notable changes to [ingress-nginx](https://github.com/kubernetes/ingress-nginx) Helm Chart. The release numbering uses [semantic versioning](http://semver.org).

### 4.10.4

* Update Ingress-Nginx version controller-v1.10.4

**Full Changelog**: https://github.com/kubernetes/ingress-nginx/compare/helm-chart-4.10.3...helm-chart-4.10.4
